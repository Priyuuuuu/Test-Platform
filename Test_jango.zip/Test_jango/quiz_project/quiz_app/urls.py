# quiz_app/urls.py

from django.urls import path
from . import views
urlpatterns = [
    path('quiz_input/', views.quiz_input, name='quiz_input'),
    path('quiz_preview/', views.quiz_preview, name='quiz_preview'),
    path('quiz_generation/', views.quiz_preview, name='quiz_generation'),
    path('add_question/', views.add_question, name='add_question'), 
    path('take_test/', views.take_test, name='take_test'),  # New URL for the test page
    path('submit_test/', views.submit_test, name='submit_test'), 
    path('edit_quiz/<int:question_index>/', views.edit_quiz, name='edit_quiz'),  # Corrected to match 'question_index'
    path('delete_quiz/<int:question_index>/', views.delete_quiz, name='delete_quiz'),  # Corrected to match 'question_index'
]
