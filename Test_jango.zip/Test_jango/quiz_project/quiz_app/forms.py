# quiz_app/forms.py

from django import forms

class QuizInputForm(forms.Form):
    content = forms.CharField(widget=forms.Textarea, label="Enter Content")
    num_questions = forms.IntegerField(min_value=1, max_value=20, initial=5, label="Number of Questions")
