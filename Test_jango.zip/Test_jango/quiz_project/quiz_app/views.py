import os
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import QuizInputForm
from django.http import JsonResponse
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
# Set up Google AI API Key
os.environ["GOOGLE_API_KEY"] = "AIzaSyDeCfka3goQtaqdQFQ6IDW2qkdneps-Otw"

# Initialize the Gemini (Google Generative AI) model
llm = ChatGoogleGenerativeAI(
    model="gemini-1.5-pro",  
    temperature=0.7,        
    max_tokens=1024,        
    timeout=60,             
    max_retries=3           
)

prompt = ChatPromptTemplate.from_messages(
    [

        ("system", "You are an AI assistant that generates multiple-choice quiz questions based on provided content. Each question must have four options and a correct answer."),
        ("human", "Generate {num_questions} quiz questions from the following content:\n{content}\n\nFormat:\nQuestion: [question text]\n   a. [option 1]\n   b. [option 2]\n   c. [option 3]\n   d. [option 4]\n   Answer: [correct answer]\n\nEnsure you provide an answer for the last question."),
    ]
)

# Combine the prompt and model into a processing chain
chain = prompt | llm

# Function to generate quizzes
def generate_quiz(content, num_questions=5):
    try:
        result = chain.invoke({"content": content, "num_questions": num_questions})
        return result.content  
    except Exception as e:
        return f"Error: {str(e)}"
# View to handle quiz input and generation
def quiz_input(request):
    if request.method == 'POST':
        form = QuizInputForm(request.POST)
        if form.is_valid():
            content = form.cleaned_data['content']
            num_questions = form.cleaned_data['num_questions']
            
            # Generate quiz questions using the prompt and model
            quiz_text = generate_quiz(content, num_questions)
            
            if "Error" in quiz_text:
                return render(request, 'quiz_app/quiz_input.html', {'form': form, 'error': quiz_text})
            
            # Store generated quiz questions in session
            questions = quiz_text.split("\n\n")
            quiz_questions = []
            for question in questions:
                if "Question:" in question and "Answer:" in question:
                    lines = question.split("\n")
                    question_text = lines[0].replace("Question: ", "").strip()
                    options = {line.split(".")[0].strip(): line.split(".")[1].strip() for line in lines[1:5]}
                    answer = lines[-1].replace("Answer: ", "").strip()
                    
                    quiz_questions.append({
                        'question': question_text,
                        'option_a': options.get("a", ""),
                        'option_b': options.get("b", ""),
                        'option_c': options.get("c", ""),
                        'option_d': options.get("d", ""),
                        'correct_answer': answer
                    })
            
            # Save the questions in the session
            request.session['quiz_questions'] = quiz_questions
            return redirect('quiz_generation')  # Redirect to the quiz preview page after saving
    else:
        form = QuizInputForm()

    return render(request, 'quiz_app/quiz_input.html', {'form': form})

# View to preview and manage quizzes
def quiz_preview(request):
    quiz_questions = request.session.get('quiz_questions', [])
    return render(request, 'quiz_app/quiz_generation.html', {'quizzes': quiz_questions})

# View to edit quiz questions
def edit_quiz(request, question_index):
    quiz_questions = request.session.get('quiz_questions', [])
    if 0 <= question_index < len(quiz_questions):
        quiz = quiz_questions[question_index]
        if request.method == 'POST':
            # Update the quiz question
            quiz['question'] = request.POST.get('question')
            quiz['option_a'] = request.POST.get('option_a')
            quiz['option_b'] = request.POST.get('option_b')
            quiz['option_c'] = request.POST.get('option_c')
            quiz['option_d'] = request.POST.get('option_d')
            quiz['correct_answer'] = request.POST.get('correct_answer')
            
            # Save updated questions in session
            request.session['quiz_questions'] = quiz_questions
            return redirect('quiz_generation')  # Redirect to the preview page after saving the edit
        return render(request, 'quiz_app/edit_quiz.html', {'quiz': quiz, 'index': question_index})
    else:
        return redirect('quiz_generation')
# View to delete quiz questions
def delete_quiz(request, question_index):
    quiz_questions = request.session.get('quiz_questions', [])
    if 0 <= question_index < len(quiz_questions):
        del quiz_questions[question_index]  # Remove the question from the list
        
        # Save updated questions in session
        request.session['quiz_questions'] = quiz_questions

    return redirect('quiz_generation')  # Redirect to the preview page after deleting the question
def add_question(request):
    if request.method == 'POST':
        form = QuizInputForm(request.POST)
        if form.is_valid():
            # Process the form and generate the question
            content = form.cleaned_data['content']
            num_questions = form.cleaned_data['num_questions']
            quiz_text = generate_quiz(content, num_questions)  # Use your existing function to generate quiz

            # Parse quiz text into question format and add to session or context
            quiz_questions = request.session.get('quiz_questions', [])
            questions = quiz_text.split("\n\n")
            for question in questions:
                if "Question:" in question and "Answer:" in question:
                    lines = question.split("\n")
                    question_text = lines[0].replace("Question: ", "").strip()
                    options = {line.split(".")[0].strip(): line.split(".")[1].strip() for line in lines[1:5]}
                    answer = lines[-1].replace("Answer: ", "").strip()
                    
                    quiz_questions.append({
                        'question': question_text,
                        'option_a': options.get("a", ""),
                        'option_b': options.get("b", ""),
                        'option_c': options.get("c", ""),
                        'option_d': options.get("d", ""),
                        'correct_answer': answer
                    })

            # Save the updated quiz questions in the session
            request.session['quiz_questions'] = quiz_questions
            return redirect('quiz_generation')  # Redirect to quiz preview page after adding question
    else:
        form = QuizInputForm()

    return render(request, 'quiz_app/add_question.html', {'form': form})

# views.py
def quiz_preview(request):
    # Retrieve the list of quiz questions from the session
    quiz_questions = request.session.get('quiz_questions', [])
    
    # Print to check the data
    print(quiz_questions)  # Check what data is being passed to the template

    # Pass the data to the template
    return render(request, 'quiz_app/quiz_generation.html', {'quizzes': quiz_questions})

def add_question(request):
    if request.method == 'POST':
        # Get the form data
        question = request.POST.get('question')
        option_a = request.POST.get('option_a')
        option_b = request.POST.get('option_b')
        option_c = request.POST.get('option_c')
        option_d = request.POST.get('option_d')
        correct_answer = request.POST.get('correct_answer')

        # Retrieve the current list of questions from the session (or create a new list if none exists)
        quiz_questions = request.session.get('quiz_questions', [])

        # Create a new question dictionary
        new_question = {
            'question': question,
            'option_a': option_a,
            'option_b': option_b,
            'option_c': option_c,
            'option_d': option_d,
            'correct_answer': correct_answer
        }
        # Append the new question to the list
        quiz_questions.append(new_question)

        # Save the updated list back to the session
        request.session['quiz_questions'] = quiz_questions

        # Debugging line to verify the data
        print(request.session['quiz_questions'])  # This should print the updated list of questions

        # Redirect to the quiz preview page after adding the question
        return redirect('quiz_preview')  # Ensure this points to the correct view

    return render(request, 'quiz_app/add_question.html')
def take_test(request):
    quizzes = request.session.get('quizzes', [])
    return render(request, 'take_test.html', {'quizzes': quizzes})
def submit_test(request):
    if request.method == 'POST':
        answers = request.POST.dict()
        quizzes = request.session.get('quizzes', [])
        score = 0
        total = len(quizzes)

        for i, quiz in enumerate(quizzes):
            if answers.get(f"question_{i}") == quiz.get('correct_answer'):
                score += 1

        return render(request, 'test_result.html', {'score': score, 'total': total})
    return redirect('quiz_preview')
